# @isoastra/fleet-scim

Framework-neutral workforce SCIM provider and PostgreSQL/native lifecycle composition. Zero runtime dependencies or framework peers; PostgreSQL connections and application-native transaction callbacks are supplied by the caller. `@isoastra/fleet-auth/scim` and `/scim-postgres` remain compatibility facades.

```ts
import { createScimProvider, workforceExternalId } from '@isoastra/fleet-scim';
import { createPostgresScimAdapter, FLEET_WORKFORCE_SCIM_MIGRATION } from '@isoastra/fleet-scim/postgres';
```

See [workforce SCIM](../../docs/workforce-scim.md) for the complete native-adapter recipe, identity and role/resource mappings, transactional revocation/readback obligations, capabilities, migrations, retry/fencing behavior and exact qualification commands. Package installation does not enable a route or outbound ZITADEL provisioning. Customer/personal accounts and business ownership remain outside workforce authority.
